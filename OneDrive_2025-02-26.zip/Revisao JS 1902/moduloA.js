exports.pontos = 500;

module.exports.ola = `Olá seja bem vindo! Você está com ${+this.pontos} pontos;`

module.exports.soma = function (a, b) {
    return a + b;
}


module.exports.subtrair = function (a, b) {
    return a - b;
}