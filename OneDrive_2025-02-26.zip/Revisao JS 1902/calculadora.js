const somar = (a, b) => a + b;
const subtrair = (a, b) => a - b;
const multiplicar = (a, b) => a * b;
const dividir = (a, b) => a / b;

module.exports = {
    somar,
    subtrair,
    multiplicar,
    dividir,
    PI: 3.1415
}