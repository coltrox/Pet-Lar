const funcA = function () {
    console.log('sou uma função');
}
export default funcA()