export default funcB = function () {
    
}