import moduloA from './moduloA';
import moduloB from './moduloB';
import {somar} from './moduloC';

console.log('Sistema de ModuleES');
moduloA();
console.log(somar(2, 4));