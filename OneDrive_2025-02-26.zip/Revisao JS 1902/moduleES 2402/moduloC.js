const somar = (a,b) => a + b;
const subtrair = (a,b) => a - b;

export {
    somar,
    subtrair
}