const moduloA = require('./moduloA');
const calculadora = require('./calculadora');

console.log (moduloA.ola);
console.log (moduloA.pontos);
console.log (moduloA.soma(2193, 124214));
console.log (moduloA.subtrair(934, 9385));

console.log (calculadora.multiplicar(978798, 78247876));
console.log (calculadora.dividir(871, 8761887));

let numero = Math.sqrt(16) * Math.pow(2, 2);